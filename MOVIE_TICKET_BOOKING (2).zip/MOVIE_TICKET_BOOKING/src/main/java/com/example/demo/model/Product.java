package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;



@Entity
@Data
public class Product {
	

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String  name;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="category_Id",referencedColumnName="category_Id")
	private Category category;
	
	private String seats;
	private String time;
	private String description;
	private String imageName;
	private Long Cost_of_per_ticket;
	private Long No_of_tickets;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public Long getCost_of_per_ticket() {
		return Cost_of_per_ticket;
	}
	public void setCost_of_per_ticket(Long cost_of_per_ticket) {
		Cost_of_per_ticket = cost_of_per_ticket;
	}
	public Long getNo_of_tickets() {
		return No_of_tickets;
	}
	public void setNo_of_tickets(Long no_of_tickets) {
		No_of_tickets = no_of_tickets;
	}
	
	
	
	

}
