package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.*;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.demo.model.Category;
import com.example.demo.model.Movie;
import com.example.demo.model.Product;
import com.example.demo.model.Seat;
import com.example.demo.model.Ticket;
import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.CategoryService;
import com.example.demo.service.MovieService;
import com.example.demo.service.ProductService;
import com.example.demo.service.SeatService;
import com.example.demo.service.TicketService;
import com.example.demo.service.UserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {
	@Autowired 
	CategoryService categoryService;
	@Autowired
	ProductService productService;
	@Autowired
	TicketService ticketService;
	@Autowired
	UserService userService;
	
	
	@GetMapping({"/","/home"})
	public String home(Model model)
	{
		
		return "index";
	}
	@GetMapping("/shop")
	public String shop(Model model)
	{
		model.addAttribute("categories",categoryService.getAllCategory());
		model.addAttribute("products",productService.getAllProduct());
		return "shop";
	}
	@GetMapping("/shop/category/{id}")
    public String shopByCategory(Model model,@PathVariable int id)
    {
		model.addAttribute("categories",categoryService.getAllCategory());
		model.addAttribute("products",productService.getAllProductByCategoryId(id));
		return "shop";
		
    }
	@GetMapping("/shop/viewproduct/{id}")
	public String viewProduct(Model model,@PathVariable int id)
	{
		model.addAttribute("product",productService.getProductById(id).get());
		return "viewProduct";
	}
	@GetMapping("/bookTicketForm/{id}")
	public String showBookticketform(Model model, @PathVariable int id) {
	    
		
	    Optional<Product> product = productService.getProductById(id);
	    if (product.isPresent()) {
	        model.addAttribute("product", product.get());
	        return "bookTicketForm";
	    } else {
	       
	        return "redirect:/shop";
	    }
	}
	@Autowired
	private SeatService seatService;
	@PostMapping("/bookticketform")
	public String bookTicket(@RequestParam String username, @RequestParam int numberOfTickets,
	                         Model model, RedirectAttributes redirectAttributes) {
	    Ticket ticket = ticketService.bookTicket(username, numberOfTickets);
	    double totalCost = ticketService.calculateTotalCost(numberOfTickets, ticket.getCostPerTicket());

	    // Add attributes to be passed to the redirected URL
	    redirectAttributes.addFlashAttribute("ticket", ticket);
	    redirectAttributes.addFlashAttribute("totalCost", totalCost);

	    return "bookTicketForm"; // Redirect to the seat page for the booked ticket
	}

	 private int selectedSeatCount = 0;
	    private double totalPrice = 0.0;

	    @GetMapping("/seat/{id}")
	    public String showSeatPage(Model model) {
	        model.addAttribute("selectedSeatCount", selectedSeatCount);
	        model.addAttribute("totalPrice", totalPrice);
	        return "seat";
	    }

	    @PostMapping("/api/seats/{seatId}/select")
	    @ResponseBody
	    public ResponseEntity<String> selectSeat(@PathVariable("seatId") Long seatId) {
	        
	        Seat selectedSeat = seatService.selectSeatById(seatId);
	        if (selectedSeat != null && !selectedSeat.Occupied()) {
	            selectedSeat.setOccupied(true); // Mark the seat as occupied
	            selectedSeatCount++; // Increment selected seat count
	            totalPrice += selectedSeat.getPrice(); // Update total price
	            return ResponseEntity.ok("Seat selected successfully."); // Return success message
	        } else {
	            return ResponseEntity.badRequest().body("Seat selection failed."); // Return error message
	        }
	    }


	@GetMapping("/login")
    public String showLoginForm() {
        return "login"; 
    }
	 @GetMapping("/register")
	    public String showSignUpForm(@ModelAttribute("user") User user) {
	        return "register"; 
	    }

	    @PostMapping("/register")
	    public String registerUser(@ModelAttribute("user") User user) {
	        userService.saveUser(user);
	        return "redirect:/login"; 
	    }
	    

	  
	
}
