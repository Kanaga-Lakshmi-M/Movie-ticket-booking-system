package com.example.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Ticket {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String userName;
	    private int numberOfTickets;
	    private double costPerTicket;
	    public Ticket() {
	    }

	    public Ticket(String userName, int numberOfTickets, double costPerTicket) {
	        this.userName = userName;
	        this.numberOfTickets = numberOfTickets;
	        this.costPerTicket = costPerTicket;
	    }
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public int getNumberOfTickets() {
			return numberOfTickets;
		}
		public void setNumberOfTickets(int numberOfTickets) {
			this.numberOfTickets = numberOfTickets;
		}
		public double getCostPerTicket() {
			return costPerTicket;
		}
		public void setCostPerTicket(double costPerTicket) {
			this.costPerTicket = costPerTicket;
		}
	    
	    

}
