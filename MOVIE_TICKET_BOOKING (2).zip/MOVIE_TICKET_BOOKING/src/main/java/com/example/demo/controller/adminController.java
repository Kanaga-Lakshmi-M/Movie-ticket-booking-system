package com.example.demo.controller;

import java.io.IOException;


import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.dto.ProductDTO;
import com.example.demo.model.Category;
import com.example.demo.model.Product;
import com.example.demo.model.User;
import com.example.demo.service.CategoryService;
import com.example.demo.service.ProductService;
import com.example.demo.service.UserService;



@Controller
public class adminController {
	public static String uploadDir=System.getProperty("user.dir")+"/src/main/resources/static/productImages";// to get current working directory
	
	
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductService productService;
	@Autowired
	UserService userService;
	
	
	
	@GetMapping("/admin")
	public String adminHome()
	{
		return "adminHome";
	}
	@GetMapping("/admin/categories")
	public String addcat(Model model)
	{
		List<Category> categories = categoryService.getAllCategory();
	    model.addAttribute("categories", categories);
		
		
		return "categories";
	}
	@GetMapping("/admin/categories/add")
	public String getcatadd(Model model)
	{
		model.addAttribute("category",new Category());
		return "categoriesAdd";
	}
	@PostMapping("/admin/categories/add")
	public String postcatadd(@ModelAttribute("category") Category category)
	{
		categoryService.addCategory(category);
		return "redirect:/admin/categories";
	}
	
	@GetMapping("/admin/categories/delete/{id}")
	public String deletecat(@PathVariable int id)
	{
		categoryService.removeCategoryById(id);
		return "redirect:/admin/categories";		
	}
	@GetMapping("/admin/categories/update/{id}")
	public String updateCat(@PathVariable int id,Model model)
	{
		Optional<Category> category=categoryService.getCategoryById(id);
		if(category.isPresent())
		{
			model.addAttribute("category",category.get());
			return "categoriesAdd";
			
		}
		else
		{
			return "484";
		}
	}
	//product section
	@GetMapping("/admin/products")
	public String product(Model model) {
	    List<Product> products = productService.getAllProduct();
	    model.addAttribute("products", products); 
	    return "products";
	}

	@GetMapping("/admin/products/add")
	public String productAddget(Model model)
	{
		model.addAttribute("productDTO",new ProductDTO());
		model.addAttribute("categories",categoryService.getAllCategory());
		
		return "productsAdd";		
	}
	@PostMapping("/admin/products/add")
	public String ProductAddPost(@ModelAttribute("productDTO")ProductDTO productDTO,@RequestParam("productImage")MultipartFile file,@RequestParam("imgName")String imgName) throws IOException{
		Product product=new Product();
		product.setId(productDTO.getId());
		product.setName(productDTO.getName());
		Optional<Category> optionalCategory = categoryService.getCategoryById(productDTO.getCategoryId());
		if (optionalCategory.isPresent()) {
		    product.setCategory(optionalCategory.get());
		} 

		product.setSeats(productDTO.getSeats());
		product.setTime(productDTO.getTime());
		product.setDescription(productDTO.getDescription());
		product.setCost_of_per_ticket(productDTO.getCost_of_per_ticket());
		String image;
		if(!file.isEmpty())
		{
			image=file.getOriginalFilename();
			Path fileNameAndPath=Paths.get(uploadDir,image);
			Files.write(fileNameAndPath, file.getBytes());
		}
		else
		{
			image=imgName;
		}
		product.setImageName(image);
		productService.addProduct(product);
		
		
		return "redirect:/admin/products";
	}
	@GetMapping("/admin/product/delete/{id}")
	public String deleteProduct(@PathVariable Long id)
	{
		productService.removeProductById(id);
		return "redirect:/admin/products";		
	}
	@GetMapping("/admin/product/update/{id}")
	public String updateProductGet(@PathVariable Long id,Model model)
	{
		Product product=productService.getProductById(id).get();
		ProductDTO productDTO=new ProductDTO();
		productDTO.setId(product.getId());
		productDTO.setCategoryId(product.getCategory().getId());
		productDTO.setSeats(product.getSeats());
		productDTO.setTime(product.getTime());
		productDTO.setDescription(product.getDescription());
		productDTO.setImageName(product.getImageName());
		
		model.addAttribute("categories",categoryService.getAllCategory());
		model.addAttribute("productDTO",productDTO);
		
		
		return "productsAdd";
	}
	
	


}