package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.model.Ticket;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;

@Service
public class TicketServiceImpl implements TicketService{
	  @PersistenceContext
	    private EntityManager entityManager;

	@Override
	public Ticket bookTicket(String userName, int numberOfTickets) {
		Ticket ticket = new Ticket(userName, numberOfTickets, 100); // Example cost per ticket
        entityManager.persist(ticket);
        return ticket;
	}

	@Override
	public double calculateTotalCost(int numberOfTickets, double costPerTicket) {
		 return numberOfTickets * costPerTicket;
	}

	@Override
	public boolean processPayment(String userName, String password, String otp) {
		// TODO Auto-generated method stub
		return false;
	}

}
