package com.example.demo.dto;

import com.example.demo.model.Category;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;



@Entity
@Data

public class ProductDTO {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long id;
	private String  name;
	

	private int categoryId;
	private  String theater;
	private String seats;
	private String time;
	private String description;
	private String imageName;
	private Long Cost_of_per_ticket;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) {
		this.theater = theater;
	}
	public String getSeats() {
		return seats;
	}
	public void setSeats(String seats) {
		this.seats = seats;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public Long getCost_of_per_ticket() {
		return Cost_of_per_ticket;
	}
	public void setCost_of_per_ticket(Long cost_of_per_ticket) {
		Cost_of_per_ticket = cost_of_per_ticket;
	}
	
	

}
