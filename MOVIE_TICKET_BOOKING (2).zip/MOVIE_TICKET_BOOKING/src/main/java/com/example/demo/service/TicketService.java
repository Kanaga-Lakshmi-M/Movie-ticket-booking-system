package com.example.demo.service;

import com.example.demo.model.Ticket;

public interface TicketService {
	
	Ticket bookTicket(String userName, int numberOfTickets);
    double calculateTotalCost(int numberOfTickets, double costPerTicket);
    boolean processPayment(String userName, String password, String otp);

}
